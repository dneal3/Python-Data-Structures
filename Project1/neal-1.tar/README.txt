Derrick Neal

Problem 1: python3 driver.py input
Problem 2: python3 driverQ.py input