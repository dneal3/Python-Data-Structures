Derrick Neal

problem 1: python3 problem1.py input
problem 2: python3 problem2.py input
problem 3: python3 problem3.py input
problem 4: python3 min_heap_driver.py input